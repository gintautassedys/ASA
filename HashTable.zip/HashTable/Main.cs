using System;
using DataStructures;
using System.IO;

namespace MainProgram
{
	public class Program
	{
		public static void Main(string [] args)
		{	
			byte[] b = new byte[100];
			for(int i = 0; i < b.Length; i++)
			{
				b[i] = (byte)(i * 10);
			}				
			Key key = new Key(5, b);
			Value value = new Value(10, b);
			DataItem dataItem = new DataItem(key, value);
			Console.WriteLine(key.ToString());
			Console.WriteLine(value.ToString());
			Console.WriteLine(dataItem.ToString());
			byte[] x = dataItem.ToByteArray();
			for(int i = 0; i < x.Length; i++)
			{
				Console.WriteLine(x[i]);
			}
		//	//GHTD("XXX.txt");
		//	//Console.WriteLine("Program for testing hash table data structure.");
		//	int size = 10;
		//	HashTable<string, string> table = new HashTable<string, string>(size);
		//	DataItem<String, String> data;
		//	HashTable<string, string> ht = GenerateHashTable(10, 5);
		//	Console.WriteLine(ht.ToString());
		//	ht.ConvertToFile("Test.txt");
		//	if(args.Length == -1)
		//	{
		//		int amount = 10000;
		//		int bottom = 1;
		//		int top = 999999;
		//		string[] keys = new string[amount];
		//		Random rnd = new Random();
		//		for(int i = 0; i < amount; i++)
		//		{
		//			keys[i] = rnd.Next(bottom, top).ToString();
		//			table.Add(keys[i], rnd.Next(bottom, top).ToString());
		//		}
		//		for(int i = 0; i < amount; i++)
		//		{	
		//			data = table.Get(keys[i]);
		//			Console.WriteLine("Key: {0}, Value: {1}", data.key, data.value);
		//		}
		//	}
		//	else if (false);
		//	{
		//		for(int i = 0; i < args.Length; i+=2)
		//		{
		//			if(i + 1 < args.Length) table.Add(args[i], args[i + 1]);
		//		}
		//		for(int i = 0; i < args.Length; i+=2)
		//		{	
		//			if(i + 1 < args.Length)
		//			{
		//				data = table.Get(args[i + 1]);
		//				//Console.WriteLine("Key: {0}, Value: {1}", data.key, data.value);
		//			}
		//		}
		//	}
		//	//Console.Write(table.ToString());
		//	
		//	bool quit = false;
		//	while(quit)
		//	{
		//		Console.WriteLine("Add - a, Get - g, Remove - r, Print - p, Quit - q, Add10 - a10");
		//		Console.WriteLine("Format: command key value");
		//		string command = Console.ReadLine();
		//		string[] temp = command.Split(' ');
		//		//if(temp.Length >= 1)
		//		//{
		//		//	switch(temp[0])
		//		//	{
		//		//		case "a":
		//		//			if (temp.Length >= 3) table.Add(temp[1], temp[2]);
		//		//			else if (temp.Length == 2) table.Add(temp[1]);
		//		//			break;
		//		//		case "g":
		//		//			if (temp.Length >= 2) Console.WriteLine(table.Get(temp[1]));
		//		//			break;
		//		//		case "r":
		//		//			if (temp.Length >= 2) Console.WriteLine(table.Remove(temp[1]));
		//		//			break;
		//		//		case "p":
		//		//			Console.WriteLine("Printing");
		//		//			Console.WriteLine(table.ToString());
		//		//			break;
		//		//		case "q":
		//		//			quit = true;
		//		//			Console.WriteLine("Quiting");
		//		//			break;
		//		//		default:
		//		//			Console.WriteLine("Wrong format");
		//		//			break;
		//		//	}
		//		//}
		//	}
		}
		//public static void GenerateHashTableData(string fileName)
		//{
		//	FileStream fs = new FileStream(fileName, FileMode.Create, FileAccess.ReadWrite);
		//	Random rnd = new Random();
		//	int amountOfDataItems = 20;
		//	int sizeOfHashTable = 10;
		//	Byte[] b = new Byte[2];
		//	
		//	int key;
		//	int value;
		//	for(int i = 0; i < amountOfDataItems; i++)
		//	{
		//		key = rnd.Next(0, 1000);
		//		value = rnd.Next(0, 1000);
		//		b[0] = (Byte)key;
		//		b[1] = (Byte)value;
		//		fs.Position = FindPositionToWrite(b[0], fs);
		//		fs.Write(b, 0, 2);
		//	}
		//	//b = new Byte[100];
		//	//for(int i = 0; i < 100; i++)
		//	//{
		//	//	b[i] = (byte)i;
		//	//}
		//	//
		//	//fs.Write(b, 0, b.Length);
		//	//fs.Position = 200;
		//	//fs.Write(b, 0, b.Length);
		//	//fs.Position = 400;
		//	//fs.Write(b, 0, b.Length);
		//	//for(int i = 0; i < 100; i++)
		//	//{
		//	//	b[i] = (byte)(i * 10);
		//	//}
		//	//fs.Position = 200;
		//	//fs.Write(b, 0, b.Length);
		//	////fs.WriteAsync(b, 50, 60);
		//}
		//
		//public static int FindPositionToWrite(Byte key, FileStream fs)
		//{
		//	int sizeOfHashTable = 10;
		//	int pos = (key.GetHashCode() % sizeOfHashTable)*2;
		//	fs.Position = pos;
		//	Byte[] b = new Byte[2];
		//	if(fs.Read(b, 0, 2) == 0) return pos;
		//	while(b[0] != 0)
		//	{
		//		Console.WriteLine(b[0]);
		//		Console.WriteLine(pos);
		//		fs.Position = pos;
		//		fs.Read(b, 0, 2);
		//		pos += sizeOfHashTable * 2;
		//	}
		//	return pos;
		//	
		//}
		//
		//public static void GHTD(string fileName)
		//{
		//	int sizeOfHashTable = 20;
		//	int sizeOfDataInBytes = 1;
		//	byte[] dataToWrite = new byte[sizeOfDataInBytes];
		//	
		//	FileStream fs = new FileStream(fileName, FileMode.Create, FileAccess.ReadWrite, FileShare.None);
		//	int placeWereToWrite = 0;
		//	byte[] dataThere = new byte[sizeOfDataInBytes];
		//	
		//	int amountOfDataToGenerate = 100;
		//	Random rnd = new Random();
		//	for(int i = 0; i < amountOfDataToGenerate; i++)
		//	{
		//		for(int j = 0; j < sizeOfDataInBytes; j++)
		//		{
		//			dataToWrite[j] = (byte)rnd.Next(0, 99);
		//		}
		//		placeWereToWrite = (dataToWrite[0].GetHashCode() % sizeOfHashTable)*sizeOfDataInBytes;
		//		fs.Position = placeWereToWrite;
		//		dataThere[0] = (byte)fs.ReadByte();
		//		//fs.Read(dataThere, 0, sizeOfDataInBytes);
		//		//Console.WriteLine("Initial Data: {0} {1}", dataThere[1], dataThere[1]);
		//		while(!(dataThere[0] == 0 || dataThere[0] == 255))
		//		{
		//			//dataThere = new byte[sizeOfDataInBytes];
		//			//Console.WriteLine("Position: {0}", fs.Position);
		//			//Console.WriteLine("Data: {0} {1}", dataThere[0], dataThere[1]);
		//			//Console.ReadKey();
		//			placeWereToWrite += sizeOfHashTable * sizeOfDataInBytes;
		//			fs.Position = placeWereToWrite;
		//			//fs.Seek(placeWereToWrite, SeekOrigin.Begin);
		//			//fs.Read(dataThere, 0, sizeOfDataInBytes);
		//			dataThere[0] = (byte)fs.ReadByte();
		//			//Console.WriteLine("Data: {0} {1}", dataThere[0], dataThere[1]);
		//		}
		//		fs.Position = placeWereToWrite;
		//		fs.Write(dataToWrite, 0, sizeOfDataInBytes);
		//		//Console.WriteLine("Succes");
		//	}
		//	
		//}
		//
		//public static void Test(string fileName)
		//{
		//	FileStream fs = new FileStream(fileName, FileMode.Create, FileAccess.ReadWrite, FileShare.None);
		//	byte b;
		//	for(byte i = 0; i < 5; i++)
		//	{
		//		Console.WriteLine("i = " + i);
		//		Console.WriteLine("     Before Writing: Position = " + fs.Position);
		//		fs.WriteByte(i);
		//		Console.WriteLine("     After Writing: Position = " + fs.Position);
		//	}
		//	fs.Position = 7;
		//	for(byte i = 7; i < 10; i++)
		//	{
		//		Console.WriteLine("i = " + i);
		//		Console.WriteLine("     Before Writing: Position = " + fs.Position);
		//		fs.WriteByte(i);
		//		Console.WriteLine("     After Writing: Position = " + fs.Position);
		//	}
		//	Console.WriteLine();
		//	fs.Position = 0;
		//	for(byte i = 0; i < 10; i++)
		//	{
		//		Console.WriteLine(fs.ReadByte());
		//	}
		//}
		//
		//public static HashTable<string, string> GenerateHashTable(int sizeOfTable, int amountOfData)
		//{
		//	int botom = 0;
		//	int top = 1000;
		//	Random ran = new Random();
		//	HashTable<string, string> ht = new HashTable<string, string>(sizeOfTable);
		//	for(int i = 0; i < amountOfData; i++)
		//	{
		//		ht.Add(ran.Next(botom, top).ToString(), ran.Next(botom, top).ToString());
		//	}
		//	return ht;
		//}
	}
}