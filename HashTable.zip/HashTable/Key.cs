namespace DataStructures
{
	public class Key
	{
		public int size {get; private set;}
		public byte[] key {get; private set;}
		
		public Key(int size, byte[] key)
		{
			this.size = size;
			this.key = new byte[size];
			int i, j; i = 0; j = 0;
			while(i < key.Length)
			{
				if(j < this.key.Length)
				{
					this.key[i] = key[i];
					i++;
					j++;
				}
				else break;
			}
		}
		
		public override string ToString()
		{
			string s = "(|";
			for(int i = 0; i < key.Length; i++)
			{
				s += (key[i].ToString("D3") + "|");
			}
			s += ")";
			return s;
		}
		
		private string ToStringAsChar()
		{
			string s = "(|";
			for(int i = 0; i < key.Length; i++)
			{
				s += ((char)key[i] + "|");
			}
			s += ")";
			return s;
		}
		
		public override bool Equals(object obj)
		{
			DataItem item = obj as DataItem;		
			if (item == null)
			{
				return false;
			}
			return key.Equals(item.key);
		}
		
		public override int GetHashCode()
		{
			return key.GetHashCode();
		}
	}
}