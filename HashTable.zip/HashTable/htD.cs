using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
namespace BinarySearchTree
{
	class Program
	{
		static Random random;
		
		static void Main(string[] args)
		{
			List<KeyValuePair> pairsList = new List<KeyValuePair>();
			HashTable hashTable = new HashTable(10);
			
			int seed = (int)DateTime.Now.Ticks & 0x0000FFFF;
			random = new Random(seed);
			int amount = 15;
			int size = 10;
			for (int i = 0; i < amount; i++)
			{
				KeyValuePair pair = new KeyValuePair(RandomName(size), RandomName(size));
				pairsList.Add(pair);
				hashTable.Add(pair);
			}
			pairsList.Add(new KeyValuePair(RandomName(size), RandomName(size)));
			
			Console.WriteLine(" Hash Table \n");
			hashTable.Print();
			//Console.WriteLine("\n Search Test \n");
			//foreach (var s in nameList)
			//{
			// Console.Write(strTree.Contains(s).ToString() + " ");
			//}
			//Console.WriteLine("\n");
			Console.WriteLine("\n Search FILE Test \n");
			string filename = @"myHashTable.dat";
			HashTable.WriteToFile(filename, amount);
			
			using (FileStream fs = new FileStream(filename, FileMode.Open, FileAccess.ReadWrite))
			{
				
				foreach (var s in pairsList)
				{
					//Console.WriteLine("Test");
					Console.Write(hashTable.FileContains(fs, s).ToString() + " ");
				}
				Console.WriteLine("\n");
			}
		}
		static string RandomName(int size)
		{
			StringBuilder builder = new StringBuilder();
			char ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 65)));
			builder.Append(ch);
			for (int i = 1; i < size; i++)
			{
				ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 97)));
				builder.Append(ch);
			}
			return builder.ToString();
		}
	}
	
	class KeyValuePair
	{
		public string key { get; private set; }
		public string value { get; private set; }
		
		public KeyValuePair(string key, string value)
		{
			this.key = key;
			this.value = value;
		}
		
		public override int GetHashCode()
		{
			return key.GetHashCode();
		}
		
		public override string ToString()
		{
			return key + " " + value;
		}
	}
	
	class HashTable
	{
		public TreeNode Root { get; set; }
		int count;
		public BinarySearchTree()
		{
			this.Root = null;
			count = 0;
		}
		public void Insert(string x)
		{
			this.Root = Insert(x, this.Root);
		}
		public bool Contains(string x)
		{
			return Contains(x, this.Root);
		}
		public bool FileContains(FileStream fs, string x)
		{
			return FileContains(fs, x, 0, this.Root.Element.Length);
		}
		public void Print()
		{
			Print(this.Root);
		}
		public void WriteToFile(string filename, int n)
		{
			byte[][] bufTree = new byte[n][];
			BuildBufTree(bufTree, this.Root, this.Root.Element.Length);
			if (File.Exists(filename)) File.Delete(filename);
			try
			{
				using (BinaryWriter writer = new BinaryWriter(File.Open(filename, FileMode.Create)))
				{
					foreach (var item in bufTree)
					{
						for (int j = 0; j < item.Length; j++)
						writer.Write(item[j]);
					}
				}
			}
			catch (IOException ex)
			{
				Console.WriteLine(ex.ToString());
			}
		}
		private void BuildBufTree(byte[][] bufTree, TreeNode t, int k)
		{
			int mn = -1;
			if (t == null)
			{
				return;
			}
			else
			{
				BuildBufTree(bufTree, t.Left, k);
				int i = t.ElementNum;
				bufTree[i] = new byte[k + 8];
				if (t.Left != null)
				BitConverter.GetBytes(t.Left.ElementNum).CopyTo(bufTree[i], 0);
				else
				BitConverter.GetBytes(mn).CopyTo(bufTree[i], 0);
				Encoding.ASCII.GetBytes(t.Element).CopyTo(bufTree[i], 4);
				if (t.Right != null)
				BitConverter.GetBytes(t.Right.ElementNum).CopyTo(bufTree[i],
				+ 4);
				else
				BitConverter.GetBytes(mn).CopyTo(bufTree[i], k + 4);
				BuildBufTree(bufTree, t.Right, k);
			}
		}
		private bool Contains(string x, TreeNode t)
		{
			while (t != null)
			{
				if ((x as IComparable).CompareTo(t.Element) < 0)
				{
					t = t.Left;
				}
				else if ((x as IComparable).CompareTo(t.Element) > 0)
				{
					t = t.Right;
				}
				else
				{
					return true;
				}
			}
			return false;
		}
		private bool FileContains(FileStream fs, string x, int t, int k)
		{
			//int ak = k + 8;
			//byte[] data = new byte[ak];
			//while (t >= 0)
			//{
			//	Console.WriteLine(t);
			//	fs.Seek(t * ak, SeekOrigin.Begin);
			//	fs.Read(data, 0, ak);
			//	int tLeft = BitConverter.ToInt32(data, 0);
			//	string element = Encoding.ASCII.GetString(data, 4, k);
			//	int tRight = BitConverter.ToInt32(data, k + 4);
			//	if ((x as IComparable).CompareTo(element) < 0)
			//	{
			//		t = tLeft;
			//	}
			//	else if ((x as IComparable).CompareTo(element) > 0)
			//	{
			//		t = tRight;
			//	}
			//	else
			//	{
			//		return true;
			//	}
			//}
			return false;
		}
		protected TreeNode Insert(string x, TreeNode t)
		{
			if (t == null)
			{
				t = new TreeNode(x, count++);
			}
			else if ((x as IComparable).CompareTo(t.Element) < 0)
			{
				t.Left = Insert(x, t.Left);
			}
			else if ((x as IComparable).CompareTo(t.Element) > 0)
			{
				t.Right = Insert(x, t.Right);
			}
			else
			{
				// throw new Exception("Duplicate item");
			}
			return t;
		}
		private void Print(TreeNode t)
		{
			if (t == null)
			{
				return;
			}
			else
			{
				Print(t.Left);
				if (t.Left != null) Console.Write("{0,3:N0} <<- ", t.Left.ElementNum); else Console.Write(" ");
				Console.Write("{0,3:N0} {1} ", t.ElementNum, t.Element);
				if (t.Right != null) Console.WriteLine(" ->> {0,3:N0}", t.Right.ElementNum); else Console.WriteLine(" ");
				Print(t.Right);
			}
		}
	}
}