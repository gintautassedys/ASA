namespace DataStructures
{
	public class Value
	{
		public int size {get; private set;}
		public byte[] value {get; private set;}
		
		public Value(int size, byte[] value)
		{
			this.size = size;
			this.value = new byte[size];
			int i, j; i = 0; j = 0;
			while(i < value.Length)
			{
				if(j < this.value.Length)
				{
					this.value[i] = value[i];
					i++;
					j++;
				}
				else break;
			}
		}
		
		public override string ToString()
		{
			string s = "(|";
			for(int i = 0; i < value.Length; i++)
			{
				s += (value[i].ToString("D3") + "|");
			}
			s += ")";
			return s;
		}
	}
}