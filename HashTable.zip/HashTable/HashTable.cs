//using System;
//using System.IO;
//using System.Collections.Generic;
//
//namespace DataStructures
//{
//	public class HashTable<Key, Value>
//	{
//		private List<DataItem<Key, Value>>[] table;
//		public int size {get; private set;}
//
//		public HashTable(int size)
//		{
//			this.size = size;
//			table = new List<DataItem<Key, Value>>[size];
//		}
//
//		public HashTable():this(100)
//		{
//		}
//
//		private int HashCode(Key key)
//		{
//			return Math.Abs(key.GetHashCode()) % size;
//		}
//
//		public bool Add(DataItem<Key, Value> item)
//		{
//			int key = HashCode(item.key);
//			if(table[key] == null)
//			{
//				table[key] = new List<DataItem<Key, Value>>();
//			}
//			table[key].Add(item);
//			return true;
//		}
//		
//		public bool Add(Key key, Value value)
//		{
//			return Add(new DataItem<Key, Value>(key, value));
//		}
//		
//		//public bool Add(Key key)
//		//{
//		//	return Add(new DataItem<Key, Value>(key));
//		//}
//
//		public DataItem<Key, Value> Get(Key key)
//		{
//			int key0 = HashCode(key);
//			if(table[key0] != null)
//			{
//				List<DataItem<Key, Value>> itemList = table[key0];
//				foreach(DataItem<Key, Value> item in itemList)
//				{
//					if(item.key.Equals(key)) return item;
//				}
//			}
//			return null;
//		}
//
//		public Value GetData(Key key)
//		{
//			return Get(key).value;
//		}
//		
//		public bool Remove(DataItem<Key, Value> item)
//		{
//			bool removed = false;
//			int key = HashCode(item.key);
//			if(table[key] != null)
//			{
//				List<DataItem<Key, Value>> itemList = table[key];
//				removed = itemList.Remove(item);
//				if(itemList.Count == 0) table[key] = null;
//			}
//			return removed;
//		}
//		
//		//public bool Remove(Key key)
//		//{
//		//	return Remove(new DataItem<Key, Value>(key));
//		//}
//
//		public override string ToString()
//		{
//			int index = 0;
//			string s = "";
//			foreach(List<DataItem<Key, Value>> itemList in table)
//			{
//				s += String.Format("{0, 4}: ", index++);
//				if(itemList != null)
//				{
//					foreach(DataItem<Key, Value> item in itemList)
//					{
//						s+= String.Format("{0, 6} -> ", item.ToString());
//					}
//				}
//				s += '\n';
//				
//			}
//			return s;
//		}
//		
//		public void ConvertToFile(string fileName)
//		{
//			FileStream fs = new FileStream(fileName, FileMode.Create, FileAccess.ReadWrite, FileShare.None);
//			int position = 0;
//			int sizeOfData = 1;
//			foreach(List<DataItem<Key, Value>> itemList in table)
//			{
//				if(itemList != null)
//				{
//					position = (itemList[0].GetHashCode() % size) * sizeOfData;
//					foreach(DataItem<Key, Value> item in itemList)
//					{
//						fs.Position = position;
//						position += sizeOfData * size;
//						fs.Write(item.ToByteArray(), 0, sizeOfData);
//					}
//				}
//			}
//		}
//	}
//}