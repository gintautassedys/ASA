using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace HashTable
{
	class Program
	{
		static Random random;
		
		static void Main(string[] args)
		{
			List<KeyValuePair> pairsList = new List<KeyValuePair>();
			HashTable hashTable = new HashTable(5);
			
			int seed = (int)DateTime.Now.Ticks & 0x0000FFFF;
			random = new Random(seed);
			int amount = 15;
			for (int i = 0; i < amount; i++)
			{
				KeyValuePair pair = new KeyValuePair(RandomName(10), RandomName(10), random.NextDouble());
				pairsList.Add(pair);
				hashTable.Add(pair);
			}
			pairsList.Add(new KeyValuePair(RandomName(10), RandomName(10), random.NextDouble()));
			
			Console.WriteLine(" Hash Table \n");
			Console.WriteLine(hashTable.ToString());
			Console.WriteLine("\n Remove Test \n");
			Console.WriteLine(pairsList[0]);
			hashTable.Remove(pairsList[0]);
			Console.WriteLine(hashTable.ToString());
			Console.WriteLine("\n Contains Test \n");
			foreach (KeyValuePair pair in pairsList)
			{
				Console.Write(hashTable.Contains(pair).ToString() + " ");
			}
			Console.WriteLine("\n");
			hashTable.ToFile("HashData.gin");
		}
		
		static string RandomName(int size)
		{
			StringBuilder builder = new StringBuilder();
			char ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 65)));
			builder.Append(ch);
			for (int i = 1; i < size; i++)
			{
				ch = Convert.ToChar(Convert.ToInt32(Math.Floor(26 * random.NextDouble() + 97)));
				builder.Append(ch);
			}
			return builder.ToString();
		}
	}
	
	class KeyValuePair
	{
		public string key { get; private set; }//Stringas is 4 simboliu
		public string value0 { get; private set; }//Stringas is 8 simboliu
		public double value1 { get; private set; }//8 byte Double verte.
		
		public KeyValuePair(string key, string value0, double value1)
		{
			this.key = key;
			this.key += new string(' ', 4);
			this.key = this.key.Substring(0, 4);
			this.value0 = value0;
			this.value0 += new string(' ', 8);
			this.value0 = this.value0.Substring(0, 8);
			this.value1 = value1;
		}
		
		public override int GetHashCode()
		{
			return key.GetHashCode();
		}
		
		public override string ToString()
		{
			return key + " " + value0 + " " + String.Format("{0:0.0000}",value1);
		}
		
		//Isviso KeyIrValue uzims 4 + 8 + 8 = 20 Baitu.
		public byte[] ToBytes()
		{
			byte[] b = new byte[20];
			for(int i = 0; i < 4; i++)
			{
				b[i] = (byte)key[i];
			}
			for(int i = 0; i < 8; i++)
			{
				b[i + 4] = (byte)value0[i];
			}
			byte[] temp = BitConverter.GetBytes(value1);
			for(int i = 0; i < 8; i++)
			{
				b[i + 12] = temp[i];
			}
			return b;
		}
	}
	
	class HashTable
	{
		public List<KeyValuePair>[] hashTable { get; set; }
		public int size { get; private set; }
		public int sizeOfDataInBytes = 20;
		
		public HashTable(int size)
		{
			this.hashTable = new List<KeyValuePair>[size];
			for(int i = 0; i < size; i++)
			{
				this.hashTable[i] = new List<KeyValuePair>();
			}
			this.size = size;
		}
		
		public HashTable():this(100)
		{
		}
		
		public void Add(string key, string value0, double value1)
		{
			Add(new KeyValuePair(key, value0, value1));
		}
		
		public void Add(KeyValuePair pair)
		{
			int index = Math.Abs(pair.GetHashCode()) % size;
			hashTable[index].Add(pair);
		}
		
		//public void FileAdd(FileStream fs, string key, string value0)
		//{
		//	FileAdd(new KeyValuePair(key, value0));
		//}
		//
		//public void FileAdd(FileStream fs, KeyValuePair pair)
		//{
		//	int index = Math.Abs(pair.GetHashCode()) % size;
		//	hashTable[index].Add(pair);
		//}
		
		public bool Contains(string key, string value0, double value1)
		{
			return Contains(new KeyValuePair(key, value0, value1));
		}
		
		public bool Contains(KeyValuePair pair)
		{
			int index = Math.Abs(pair.GetHashCode()) % size;
			if(hashTable[index] != null)
			{
				return hashTable[index].Contains(pair);
			}
			return false;
		}
		
		public bool Remove(string key, string value0, double value1)
		{
			return Remove(new KeyValuePair(key, value0, value1));
		}
		
		public bool Remove(KeyValuePair pair)
		{
			int index = Math.Abs(pair.GetHashCode()) % size;
			if(hashTable[index] != null)
			{
				return hashTable[index].Remove(pair);
			}
			return false;
		}
		
		public override string ToString()
		{
			string s = "";
			for(int i = 0; i < hashTable.Length; i++)
			{
				s += String.Format("{0:D3}: ", i);
				if(hashTable[i] != null)
				{
					foreach(KeyValuePair pair in hashTable[i])
					{
						s += pair.ToString() + " -> "; 
					}
				}
				s += '\n';
			}
			return s;
		}
		
		public void ToFile(string fileName)
		{	
			FileStream fs = new FileStream(fileName, FileMode.Create, FileAccess.ReadWrite, FileShare.None);
			int placeWereToWrite = 0;
			
			for(int i = 0; i < size; i++)
			{
				int j = 0;
				foreach(KeyValuePair pair in  hashTable[i])
				{
					placeWereToWrite = ((Math.Abs(pair.GetHashCode()) % size) + (size * j))*sizeOfDataInBytes;
					fs.Position = placeWereToWrite;
					fs.Write(pair.ToBytes(), 0, sizeOfDataInBytes);
					j++;
				}
			}		
		}

		//public void FromFile(string fileName)
		//{	
		//	FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.ReadWrite, FileShare.None);
		//	for(int i = 0; i < size; i++)
		//	{
		//		int j = 0;
		//		foreach(KeyValuePair pair in  hashTable[i])
		//		{
		//			placeWereToWrite = ((Math.Abs(pair.GetHashCode()) % size) + (size * j))*sizeOfDataInBytes;
		//			fs.Position = placeWereToWrite;
		//			fs.Write(pair.ToBytes(), 0, sizeOfDataInBytes);
		//			j++;
		//		}
		//	}
		//	
		//}
	}
}