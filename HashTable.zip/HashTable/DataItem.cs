namespace DataStructures
{
	public class DataItem
	{
		public Key key {get; private set;}
		public Value value {get; private set;}
		public int size {get; private set;}
		
		public DataItem(Key key, Value value)
		{
			this.key = key;
			this.value = value;
			size = key.size + value.size;
		}
		
		public override bool Equals(object obj)
		{
			DataItem item = obj as DataItem;		
			if (item == null)
			{
				return false;
			}
			return key.Equals(item.key);
		}
		
		public override int GetHashCode()
		{
			return key.GetHashCode();
		}
		
		public override string ToString()
		{
			return "key: " + key.ToString() + ", value: " + value.ToString();
		}
		
		public byte[] ToByteArray()
		{
			byte[] b = new byte[size];
			for(int i = 0; i < key.size; i++)
			{
				b[i] = key.key[i];
			}
			for(int i = 0; i < value.size; i++)
			{
				b[i + key.size] = value.value[i];
			}
			return b;
		}
	}
}